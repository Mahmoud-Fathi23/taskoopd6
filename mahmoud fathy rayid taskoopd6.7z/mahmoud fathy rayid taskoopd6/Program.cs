﻿using System;
using System.Drawing;

namespace ConsoleApp44
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region part2
            //Point defaultPoint = new Point();
            //Point paramPoint = new Point(5, 10);

            //Console.WriteLine(defaultPoint); 
            //Console.WriteLine(paramPoint);   

            //typeA typeA = new typeA();
            //typeA.DisplayAttributes();
            //Console.WriteLine(typeA.H); 
            #endregion

            #region part3
            //Employee emp = new Employee();
            //emp.EmployeeId = 101;
            //emp.SetName("John Doe");
            //emp.EmployeeSalary = 50000.0;

            //Console.WriteLine($"EmpId: {emp.EmployeeId}, Name: {emp.GetName()}, Salary: {emp.EmployeeSalary}");
            #endregion
            #region part4
            //Point point1 = new Point(5); 
            //Point point2 = new Point(5, 10); 

            //Console.WriteLine(point1); 
            //Console.WriteLine(point2);
            #endregion
            #region part5
            //Point point1 = new Point(5); 
            //Point point2 = new Point(5, 10); 
            //Point point3 = new Point(15, 20); 

            //Console.WriteLine(point1); 
            //Console.WriteLine(point2); 
            //Console.WriteLine(point3); 
            #endregion
        }
    }
}
